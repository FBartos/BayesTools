.onLoad <- function(libname, pkgname){

  # load runjags
  # requireNamespace("rjags")
  # requireNamespace("runjags")
}
